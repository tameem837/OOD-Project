package bd.edu.diu.swe.purplesense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PurpleSenseEcommerceSpringBoot {

	public static void main(String[] args) {
		SpringApplication.run(PurpleSenseEcommerceSpringBoot.class, args);
	}

}
